package backendDevelopers.FirstSpringBoot;

import java.util.HashMap;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;

@SpringBootApplication
public class FirstSpringBootApplication {
    
	//entry point for springboot application
	public static void main(String[] args) {
		
	
				
				SpringApplication spr= new SpringApplication(FirstSpringBootApplication.class);
				System.out.println("enter port number");
				Scanner scan=new Scanner(System.in);
				int port=scan.nextInt();
				HashMap portconf=new HashMap();
				portconf.put("server.port", port);
				spr.setDefaultProperties(portconf);
				spr.run(args);
				
				System.out.println("started the server");
				
			

		}

	}


