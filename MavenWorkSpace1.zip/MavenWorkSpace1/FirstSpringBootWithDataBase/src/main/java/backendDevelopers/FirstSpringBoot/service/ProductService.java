package backendDevelopers.FirstSpringBoot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import backendDevelopers.FirstSpringBoot.dao.ProductList;
import backendDevelopers.FirstSpringBoot.model.Product;

  //@Service automatically creates bean for  ProductService
@Service   //any class marked with @Service controls concurrent or parallel access to dao layer there by preventing data loss or data corruption
public class ProductService {
	//manually injecting the ProductList into ProductService
	@Autowired
	ProductList plist;

	public ArrayList< Product> getproductList(){
		System.out.println("getting product list");
		return (ArrayList<Product>)plist.findAll();  //findAll() executes a SQL select * from Products statement on the data base
			
	}
	public String addProduct(Product p) {
		System.out.println(" in service.adding product");
		Product t= plist.save(p);    //converts this to SQL insert statement
		return "<b>added or inserted thr product</b>" +t;
		
	}  
	
	public String deleteProduct(int productId) {
		System.out.println("in service. deleting product");
		plist.deleteById(productId);
		return "<b>deleted product with id</b>" + productId;
		
	}

	public String searchProduct(int productId) {
		System.out.println("in service. searching by id");
		Optional<Product> opt = plist.findById(productId);
		return "located product" + opt.get().toString();
		
	}

	public String updateProduct(int productId,String productName) {
		System.out.println("in service. updating product");
		Product d= new Product(productId, productName);
		return "updated product with" + plist.save(d).toString();
	}
	



}
