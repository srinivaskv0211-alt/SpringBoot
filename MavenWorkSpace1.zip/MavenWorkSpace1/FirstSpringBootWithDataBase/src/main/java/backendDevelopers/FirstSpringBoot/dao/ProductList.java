package backendDevelopers.FirstSpringBoot.dao;


import java.util.HashMap;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import backendDevelopers.FirstSpringBoot.model.Product;

@Repository
public interface ProductList extends CrudRepository <Product, Integer>
{
	

}
