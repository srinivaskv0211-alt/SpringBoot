package backendDevelopers.FirstSpringBoot.controller;

import java.awt.PageAttributes.MediaType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaTypeEditor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import backendDevelopers.FirstSpringBoot.model.Product;
import backendDevelopers.FirstSpringBoot.service.ProductService;

@RestController   //converts normal java class into controller
@RequestMapping("/shopping")
public class Shopping {
	public long visitorCount=0;
	
	@Autowired
	ProductService service;
	public Shopping() {
		System.err.println("shopping controller created"); //err is used to print log messages
	
	}
	//link this api with browser
	//if the url is http://localhost:9080/shopping/, the call home() method and return response to client
	@RequestMapping(path= "/", method=RequestMethod.GET)
	public ModelAndView home() {
		visitorCount++;
		ModelAndView mv=new ModelAndView();
		mv.setViewName("home");
		mv.addObject("visCount", visitorCount);
		return mv;
		
		
		
	}
	@GetMapping(path="/list",produces=org.springframework.http.MediaType.APPLICATION_JSON_VALUE) //if the url ends with /list then getproductList()	method returns list of products
	public ModelAndView getproductList() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("listProduct");
		mv.addObject("products", service.getproductList());
		return mv; 
		
	}
	//@RequestParam indicates that the value for productid is sent at the end of the url
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pId") int productId) {
		
		return service.searchProduct(productId);
	}
		
	@PostMapping("/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("productId") int productId) {
	    ModelAndView mv = new ModelAndView();
	    Product product = service.deleteProduct(productId);

	    mv.setViewName("deletedProduct");
	    mv.addObject("today", new java.util.Date().toString());

	    if (product != null) {
	        mv.addObject("product", product);
	    } else {
	        mv.addObject("error", "Product with ID " + productId + " not found!");
	    }

	    return mv;
	}
	@GetMapping("/delete")
	public ModelAndView showDeleteForm() {
	    ModelAndView mv = new ModelAndView();
	    mv.setViewName("deleteProduct");
	    mv.addObject("today", new java.util.Date().toString());
	    
	   
	    List<Product> products = service.getAllProducts(); 
	    mv.addObject("products", products);

	    return mv;
	}

	@GetMapping(path="/add")
	public ModelAndView addP() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addProduct");
		mv.addObject("Today", new java.util.Date().toString());
		visitorCount++;
		mv.addObject("vCount", visitorCount);
		return mv;
		
		
	}
	
	
	@PostMapping(path="/addProduct")  //@PostMapping is used to receive POST request from the client
	public ModelAndView addProduct(@ModelAttribute Product p) {
		ModelAndView mv = new ModelAndView();
		System.out.println("got a post request");
		Product m=service.addProduct(p);
		mv.setViewName("addedProduct");
		mv.addObject("product",m);
		return mv;
		
	}
	@PutMapping(path="/update" , consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)  //@PostMapping is used to receive POST request from the client
	public String updateProduct(@RequestBody Product p) {
		return service.updateProduct(p.getProductId(),p.getProductName());
		
	}
	
	
}
