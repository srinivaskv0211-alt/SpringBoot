package backendDevelopers.FirstSpringBoot.service;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import backendDevelopers.FirstSpringBoot.dao.ProductList;
import backendDevelopers.FirstSpringBoot.model.Product;

  //@Service automatically creates bean for  ProductService
@Service   //any class marked with @Service controls concurrent or parallel access to dao layer there by preventing data loss or data corruption
public class ProductService {
	//manually injecting the ProductList into ProductService
	ProductList plist=new ProductList();

	public HashMap<Integer , Product> getproductList(){
		System.out.println("getting product list");
		return plist.getproductList();
		
	}
	public String addProduct(Product p) {
		System.out.println(" in service.adding product");
		return plist.addProduct(p);
		
	}  
	
	public String deleteProduct(int productId) {
		System.out.println("in service. deleting product");
		return plist.deleteProduct(productId);
		
	}

	public String searchProduct(int productId) {
		System.out.println("in service. searching by id");
		return plist.searchProduct(productId);	
		
	}

	public String updateProduct(int productId,String productName) {
		System.out.println("in service. updating product");
		return plist.updateProduct(productId, productName);
	}
	



}
