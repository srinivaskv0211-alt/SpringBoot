package backendDevelopers.FirstSpringBoot.dao;

import java.beans.JavaBean;
import java.util.HashMap;

import backendDevelopers.FirstSpringBoot.model.Product;

@JavaBean
public class ProductList {
	public HashMap<Integer,Product> productList=new HashMap<>();
	
	public ProductList() {
		productList.put(1, new Product(1,"samsung s24"));
		productList.put(2, new Product(2,"iphone 17"));
		productList.put(3, new Product(3,"samsung z fold"));
		productList.put(4, new Product(4,"iphone 16"));
		System.err.println("product list created");
	}
	
	public HashMap<Integer , Product> getproductList(){
		System.out.println("retrieved product list and sent it");
		return productList;
	}
	public String addProduct(Product p) {
		productList.put(p.getProductId(), p);
		System.err.println("added a new product");  //err prints a log message
		return" product added succesfully,"
				+ " use /list to get updated list of products";
	}
	
	public String deleteProduct(int productId) {
		Product p=productList.get(productId);
		if (p != null) {
			productList.remove(productId);
			return "<b>product found and deleted</b>;" +p;  
		}
			else
				return "<b>product not found</b>";
	
	}

	public String searchProduct(int productId) {
		Product p=productList.get(productId);
		if (p != null) {
			return "<b>product found</b>;" +p;  
		}else
				return "<b>product not found</b>"; 
		
	}

	public String updateProduct(int productId,String productName) {
		Product p=productList.get(productId);
		if(p!=null) {
			p.setProductName(productName);
			productList.put(p.getProductId(), p);
			return "<b> product found and updated</b>";
		}else
			return"<b>product not found</b>";
		
	}


}
