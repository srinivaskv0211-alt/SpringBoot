package backendDevelopers.FirstSpringBoot.model;

public class Product {
	private int productId;
	private String productName;
	
	public Product() {
		super();
		System.out.println("new product created");
	}
	
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
		System.out.println("new product created with productId ans productName");
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + "]"
				+ "   -   " +hashCode();
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
		System.out.println("stored product id");

	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
		System.out.println("stored product name");

	}

}
