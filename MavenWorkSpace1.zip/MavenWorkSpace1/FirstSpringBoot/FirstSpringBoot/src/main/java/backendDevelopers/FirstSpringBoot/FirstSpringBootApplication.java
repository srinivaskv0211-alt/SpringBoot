package backendDevelopers.FirstSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;

@SpringBootApplication
public class FirstSpringBootApplication {
    
	//entry point for springboot application
	public static void main(String[] args) {
		
		
		//start the tomcat server and deploy the website or application on the tomcat server
		SpringApplication.run(FirstSpringBootApplication.class, args);
		System.out.println("started the server");
	}

}
