package backendDevelopers.FirstSpringBoot.controller;

import java.awt.PageAttributes.MediaType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaTypeEditor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import backendDevelopers.FirstSpringBoot.model.Product;
import backendDevelopers.FirstSpringBoot.service.ProductService;

@RestController   //converts normal java class into controller
@RequestMapping("/shopping")
public class Shopping {
	public long visitorCount=0;
	
	@Autowired
	ProductService service;
	public Shopping() {
		System.err.println("shopping controller created"); //err is used to print log messages
	
	}
	//link this api with browser
	//if the url is http://localhost:9080/shopping/, the call home() method and return response to client
	@RequestMapping(path= "/", method=RequestMethod.GET)
	public String home() {
		visitorCount++;
		String response="<html><body><h1>";
		response += "welcome to online shopping</h1><br>";
		response += "<b>you are visitor # </b>" + visitorCount;
		response += "</body></html>";
		return response;
		
	}
	@GetMapping(path="/list",produces=org.springframework.http.MediaType.APPLICATION_JSON_VALUE) //if the url ends with /list then getproductList()	method returns list of products
	public HashMap<Integer,Product> getproductList() {
		return service.getproductList();
	}
	//@RequestParam indicates that the value for productid is sent at the end of the url
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pId") int productId) {
		
		return service.searchProduct(productId);
	}
		
	@DeleteMapping("/deleteId/{pId}") //used to delete request
	public String deleteProduct(@PathVariable("pId") int productId)  //@RequestBody is used when client sends data from html 
	{
		return service.deleteProduct(productId);

	}
	@PostMapping(path="/add" , consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)  //@PostMapping is used to receive POST request from the client
	public String addProduct(@RequestBody Product p) {
		
		System.out.println("got a post request");
		return service.addProduct(p);
		
	}
	@PutMapping(path="/update" , consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)  //@PostMapping is used to receive POST request from the client
	public String updateProduct(@RequestBody Product p) {
		return service.updateProduct(p.getProductId(),p.getProductName());
		
	}
	
	
}
