package Cricket.Ipl2025.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import Cricket.Ipl2025.model.Team;

@Repository
public interface TeamList extends CrudRepository <Team, Integer> {

}
