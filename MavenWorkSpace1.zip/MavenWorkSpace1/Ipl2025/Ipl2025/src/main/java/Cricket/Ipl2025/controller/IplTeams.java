package Cricket.Ipl2025.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Cricket.Ipl2025.model.Team;
import Cricket.Ipl2025.service.TeamService;

@RestController   
@RequestMapping("/iplteams")
public class IplTeams {
	public long visitorCount=0;
	
	@Autowired
	TeamService service;
	public IplTeams() {
		System.err.println("teams controller created"); 
	
	}
	
	@RequestMapping(path= "/", method=RequestMethod.GET)
	public String home() {
		visitorCount++;
		String response="<html><body><h1>";
		response += "welcome to IpL 2025</h1><br>";
		response += "<b>you are visitor # </b>" + visitorCount;
		response += "</body></html>";
		return response;
		
	}
	@GetMapping(path="/list",produces=org.springframework.http.MediaType.APPLICATION_JSON_VALUE) //if the url ends with /list then getproductList()	method returns list of products
	public ArrayList<Team> getTeamList() {
		return service.getTeamList();
	}
	@GetMapping("/search")
	public String searchTeam(@RequestParam("tId") int teamId) {
		
		return service.searchTeam(teamId);
	}
		
	@DeleteMapping("/deleteId/{tId}") 
	public String deleteTeam(@PathVariable("tId") int teamId)  
	{
		return service.deleteTeam(teamId);

	}
	@PostMapping(path="/add" , consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE) 
	public String addTeam(@RequestBody Team t) {
		
		System.out.println("got a post request");
		return service.addTeam(t);
		
	}
	@PutMapping(path="/update" , consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)  
	public String updateTeam(@RequestBody Team t) {
		return service.updateTeam(t.getTeamId(),t.getTeamName());
		
	}
	
	
}
