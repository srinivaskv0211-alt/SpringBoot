package Cricket.Ipl2025.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Team")
public class Team {
	@Id  //in database this is a primary key
	@GeneratedValue(strategy =GenerationType.AUTO)
	private int teamId;
	
	@Column(name="teamName")  //link product name variable with productname column in database
	private String teamName;
	
	public Team() {
		super();
		System.out.println("new team created");
	}
	
	public Team(int teamId, String teamName) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		System.out.println("new team created with teamId ans teamName");
	}

	@Override
	public String toString() {
		return "Team [teamId=" + teamId + ", teamName=" + teamName + "]"
				+ "   -   " +hashCode();
	}
	public int getTeamId() {
		return teamId;
	}
	public void setteamId(int teamId) {
		this.teamId = teamId;
		System.out.println("stored  teamid");

	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
		System.out.println("stored team name");

	}

}