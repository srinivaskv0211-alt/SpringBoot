package Cricket.Ipl2025.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Cricket.Ipl2025.dao.TeamList;
import Cricket.Ipl2025.model.Team;

@Service  
public class TeamService {
	@Autowired
	TeamList tlist;

	public ArrayList<Team> getTeamList(){
		System.out.println("getting team list");
		return (ArrayList<Team>)tlist.findAll();
			
	}
	public String addTeam(Team t) {
		System.out.println(" in service.adding team");
		Team a= tlist.save(t);    
		return "<b>added or inserted thr team</b>" +a;
		
	}  
	
	public String deleteTeam(int teamId) {
		System.out.println("in service. deleting team");
		tlist.deleteById(teamId);
		return "<b>deleted team with id</b>" + teamId;
		
	}

	public String searchTeam(int teamId) {
		System.out.println("in service. searching by id");
		Optional<Team> opt = tlist.findById(teamId);
		return "located team" + opt.get().toString();
		
	}

	public String updateTeam(int teamId,String teamName) {
		System.out.println("in service. updating team");
		Team b= new Team(teamId, teamName);
		return "updated product with" + tlist.save(b).toString();
	}
	



}

